/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,
  // Add more config here if needed (images, rewrites, etc)
};

module.exports = nextConfig;
